# AI-PID-Automation

AI-assisted workflow for P&ID digitalization, graph-based process representation, machine learning surrogate modeling and multi-objective optimization for chemical engineering applications.

## Project Scope

This repository contains a research notebook workflow for converting P&ID/CAD information into graph structures and linking those graphs with AI/ML models for process prediction and optimization. The current notebook includes modules for P&ID parsing, NetworkX graph generation, Graph Neural Network concepts, ANN-based surrogate modeling and NSGA-II optimization.

## Main Modules

### 1. P&ID Parsing and Graph Construction

- Reads DXF P&ID drawings using `ezdxf`
- Extracts TEXT, MTEXT and INSERT entities
- Extracts pipeline geometry using Shapely
- Cleans and normalizes node coordinates
- Applies DBSCAN clustering for node filtering
- Builds process graphs using NetworkX
- Exports node and edge information for downstream ML use

### 2. GNN-based P&ID Digital Twin

- Converts equipment and pipe networks into graph format
- Demonstrates GraphSAGE/GNN-style node embedding workflow
- Supports reactor/equipment node identification
- Provides a foundation for AI-assisted P&ID automation and digital twin development

### 3. ANN Surrogate Modeling

The ANN surrogate model predicts process performance from catalyst and operating variables.

**Inputs include:**

- SiO2/Al2O3 ratio
- ZSM-5 loading
- Temperature
- CTO ratio

**Outputs include:**

- Conversion
- Gasoline yield
- Coke yield
- Dry gas
- Bottom fraction

### 4. NSGA-II Multi-objective Optimization

The optimization workflow uses `pymoo` to identify optimal operating conditions for competing objectives.

**Objectives include:**

- Maximize conversion
- Maximize gasoline yield
- Minimize coke formation

### 5. HDO Catalyst ML Optimization

The notebook also includes a hydrodeoxygenation/catalyst screening workflow for evaluating catalyst performance and product-quality indicators such as oxygen removal, water formation, HHV and DOD-related metrics.

## Repository Structure

```text
AI-PID-Automation/
│
├── README.md
├── requirements.txt
├── .gitignore
│
├── notebooks/
│   ├── 01_PID_Parsing_and_Graph_Construction.ipynb
│   ├── 02_GNN_PID_Digital_Twin.ipynb
│   ├── 03_ANN_FCC_Surrogate_Model.ipynb
│   ├── 04_NSGAII_FCC_Optimization.ipynb
│   ├── 05_HDO_Catalyst_ML_Optimization.ipynb
│   └── PID_Automation_Complete_Cleaned.ipynb
│
├── data/
│   ├── raw/
│   └── processed/
│
├── src/
├── models/
├── results/
├── figures/
└── docs/
```

## Suggested Outputs to Save

Save generated outputs in the following folders:

```text
figures/
├── pid_graph.png
├── normalized_nodes.png
├── cluster_plot.png
├── ann_loss_curve.png
├── parity_plot.png
├── feature_importance.png
├── pareto_front.png
└── hdo_optimization_plot.png

results/
├── nodes.csv
├── edges.csv
├── predictions.csv
├── model_metrics.csv
└── optimization_results.csv

models/
├── ann_model.pth
├── gnn_model.pth
├── scaler.pkl
└── encoder.pkl
```

## Installation

```bash
pip install -r requirements.txt
```

## Key Python Libraries

- NumPy
- Pandas
- Matplotlib
- Scikit-learn
- PyTorch
- Torch Geometric
- NetworkX
- EZDXF
- Shapely
- Pymoo
- Graphviz
- Ipywidgets

## How to Use

1. Open the notebooks in Google Colab or Jupyter.
2. Start with `01_PID_Parsing_and_Graph_Construction.ipynb`.
3. Upload a DXF P&ID file when prompted.
4. Generate nodes, edges and graph outputs.
5. Run ANN surrogate modeling and NSGA-II optimization notebooks.
6. Save generated plots in `figures/`, metrics in `results/` and trained models in `models/`.

## Status

Research under development.

## Important Note

This repository should remain private if it contains confidential company data, internal P&IDs, proprietary datasets, unpublished patent concepts, or internal process know-how.
