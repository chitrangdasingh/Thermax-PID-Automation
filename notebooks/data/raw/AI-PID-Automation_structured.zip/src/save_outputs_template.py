"""Utility examples for saving Colab outputs into project folders."""
import os
import pandas as pd
import matplotlib.pyplot as plt

for folder in ["figures", "results", "models", "data/raw", "data/processed"]:
    os.makedirs(folder, exist_ok=True)


def save_current_plot(filename: str):
    """Save the active matplotlib figure in high resolution."""
    plt.savefig(f"figures/{filename}", dpi=300, bbox_inches="tight")


def save_dataframe(df: pd.DataFrame, filename: str):
    """Save a dataframe into results folder."""
    df.to_csv(f"results/{filename}", index=False)
